
package Interfaces_Recepcionista;
import Clases.disponibilidad;

public class Limpieza extends javax.swing.JFrame {
    public Limpieza() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        tip_H = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        hab1 = new javax.swing.JLabel();
        alquilarH1 = new javax.swing.JButton();
        hab11 = new javax.swing.JLabel();
        hab12 = new javax.swing.JLabel();
        hab22 = new javax.swing.JLabel();
        hab23 = new javax.swing.JLabel();
        hab2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        alquilarH2 = new javax.swing.JButton();
        hab32 = new javax.swing.JLabel();
        hab33 = new javax.swing.JLabel();
        hab3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        alquilarH3 = new javax.swing.JButton();
        hab42 = new javax.swing.JLabel();
        hab43 = new javax.swing.JLabel();
        hab4 = new javax.swing.JLabel();
        alquilarH4 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        hab52 = new javax.swing.JLabel();
        hab53 = new javax.swing.JLabel();
        hab5 = new javax.swing.JLabel();
        alquilarH5 = new javax.swing.JButton();
        hab6 = new javax.swing.JLabel();
        hab62 = new javax.swing.JLabel();
        hab72 = new javax.swing.JLabel();
        hab73 = new javax.swing.JLabel();
        hab7 = new javax.swing.JLabel();
        hab82 = new javax.swing.JLabel();
        hab83 = new javax.swing.JLabel();
        hab8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        hab92 = new javax.swing.JLabel();
        hab93 = new javax.swing.JLabel();
        hab9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        hab101 = new javax.swing.JLabel();
        hab102 = new javax.swing.JLabel();
        hab10 = new javax.swing.JLabel();
        hab63 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        alquilarH6 = new javax.swing.JButton();
        alquilarH7 = new javax.swing.JButton();
        alquilarH8 = new javax.swing.JButton();
        alquilarH9 = new javax.swing.JButton();
        alquilarH10 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("Tipo de Habitación a alquilar ");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(217, 34, -1, -1));

        tip_H.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Personal", "Familiar", "Matrimonial" }));
        getContentPane().add(tip_H, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 31, -1, -1));

        jButton1.setText("Ver");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(555, 31, -1, -1));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionMar.jpg"))); // NOI18N
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 130, 170, 130));

        hab1.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 260, 180, 20));

        alquilarH1.setText("Realizar limpieza");
        alquilarH1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH1ActionPerformed(evt);
            }
        });
        getContentPane().add(alquilarH1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 340, -1, -1));

        hab11.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab11, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 280, 180, 20));

        hab12.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab12, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 300, 180, 20));

        hab22.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab22, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 280, 180, 20));

        hab23.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab23, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 300, 180, 20));

        hab2.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab2, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 260, 180, 20));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionMar.jpg"))); // NOI18N
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 120, 170, 130));

        alquilarH2.setText("Realizar limpieza");
        getContentPane().add(alquilarH2, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 340, -1, -1));

        hab32.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab32, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 280, 180, 20));

        hab33.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab33, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 300, 180, 20));

        hab3.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab3, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 260, 180, 20));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionNmar.png"))); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 120, 170, 130));

        alquilarH3.setText("Realizar limpieza");
        getContentPane().add(alquilarH3, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 340, -1, -1));

        hab42.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab42, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 280, 180, 20));

        hab43.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab43, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 300, 180, 20));

        hab4.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab4, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 260, 180, 20));

        alquilarH4.setText("Realizar limpieza");
        alquilarH4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH4ActionPerformed(evt);
            }
        });
        getContentPane().add(alquilarH4, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 340, -1, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionNmar.png"))); // NOI18N
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 120, 170, 130));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionNmar.png"))); // NOI18N
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 120, 170, 130));

        hab52.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab52, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 280, 180, 20));

        hab53.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab53, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 300, 180, 20));

        hab5.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 260, 180, 20));

        alquilarH5.setText("Realizar limpieza");
        alquilarH5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH5ActionPerformed(evt);
            }
        });
        getContentPane().add(alquilarH5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 340, -1, -1));

        hab6.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab6, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 540, 180, 20));

        hab62.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab62, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 560, 180, 20));

        hab72.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab72, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 560, 180, 20));

        hab73.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab73, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 580, 180, 20));

        hab7.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab7, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 540, 180, 20));

        hab82.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab82, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 560, 180, 20));

        hab83.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab83, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 580, 180, 20));

        hab8.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab8, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 540, 180, 20));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionNmar.png"))); // NOI18N
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 400, 170, 130));

        hab92.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab92, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 560, 180, 20));

        hab93.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab93, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 580, 180, 20));

        hab9.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab9, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 540, 180, 20));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionNmar.png"))); // NOI18N
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 400, 170, 130));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionNmar.png"))); // NOI18N
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 400, 170, 130));

        hab101.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab101, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 560, 180, 20));

        hab102.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab102, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 580, 180, 20));

        hab10.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab10, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 540, 180, 20));

        hab63.setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().add(hab63, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 580, 180, 20));

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionNmar.png"))); // NOI18N
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 400, 170, 130));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionNmar.png"))); // NOI18N
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 400, 170, 130));

        alquilarH6.setText("Realizar limpieza");
        alquilarH6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH6ActionPerformed(evt);
            }
        });
        getContentPane().add(alquilarH6, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 620, -1, -1));

        alquilarH7.setText("Realizar limpieza");
        alquilarH7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH7ActionPerformed(evt);
            }
        });
        getContentPane().add(alquilarH7, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 620, -1, -1));

        alquilarH8.setText("Realizar limpieza");
        alquilarH8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH8ActionPerformed(evt);
            }
        });
        getContentPane().add(alquilarH8, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 620, -1, -1));

        alquilarH9.setText("Realizar limpieza");
        alquilarH9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH9ActionPerformed(evt);
            }
        });
        getContentPane().add(alquilarH9, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 620, -1, -1));

        alquilarH10.setText("Realizar limpieza");
        alquilarH10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH10ActionPerformed(evt);
            }
        });
        getContentPane().add(alquilarH10, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 620, -1, -1));

        jButton2.setText("Volver");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 110, 30));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
     String tipHa = tip_H.getSelectedItem().toString();
     disponibilidad d= new disponibilidad ();
        d.seedisp(tipHa, hab1, hab11, hab12, hab10, hab101, hab102, hab2, hab22, hab23, hab3, hab32, hab33, hab4, hab42, hab43, hab5, hab52, hab53, hab6, hab62, hab63, hab7, hab72, hab73, hab8, hab82, hab83, hab9, hab92, hab93, hab1, hab2, hab3, hab4, hab5, hab6, hab7, hab8, hab9, hab10);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void alquilarH4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_alquilarH4ActionPerformed

    private void alquilarH5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_alquilarH5ActionPerformed

    private void alquilarH6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_alquilarH6ActionPerformed

    private void alquilarH7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_alquilarH7ActionPerformed

    private void alquilarH8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_alquilarH8ActionPerformed

    private void alquilarH9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_alquilarH9ActionPerformed

    private void alquilarH10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_alquilarH10ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    Principal_Hotel p=new Principal_Hotel();
    p.setVisible(true);
    p.setLocationRelativeTo(null);
    this.dispose();
// TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void alquilarH1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH1ActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_alquilarH1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Limpieza.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Limpieza.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Limpieza.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Limpieza.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Limpieza().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton alquilarH1;
    private javax.swing.JButton alquilarH10;
    private javax.swing.JButton alquilarH2;
    private javax.swing.JButton alquilarH3;
    private javax.swing.JButton alquilarH4;
    private javax.swing.JButton alquilarH5;
    private javax.swing.JButton alquilarH6;
    private javax.swing.JButton alquilarH7;
    private javax.swing.JButton alquilarH8;
    private javax.swing.JButton alquilarH9;
    private javax.swing.JLabel hab1;
    private javax.swing.JLabel hab10;
    private javax.swing.JLabel hab101;
    private javax.swing.JLabel hab102;
    private javax.swing.JLabel hab11;
    private javax.swing.JLabel hab12;
    private javax.swing.JLabel hab2;
    private javax.swing.JLabel hab22;
    private javax.swing.JLabel hab23;
    private javax.swing.JLabel hab3;
    private javax.swing.JLabel hab32;
    private javax.swing.JLabel hab33;
    private javax.swing.JLabel hab4;
    private javax.swing.JLabel hab42;
    private javax.swing.JLabel hab43;
    private javax.swing.JLabel hab5;
    private javax.swing.JLabel hab52;
    private javax.swing.JLabel hab53;
    private javax.swing.JLabel hab6;
    private javax.swing.JLabel hab62;
    private javax.swing.JLabel hab63;
    private javax.swing.JLabel hab7;
    private javax.swing.JLabel hab72;
    private javax.swing.JLabel hab73;
    private javax.swing.JLabel hab8;
    private javax.swing.JLabel hab82;
    private javax.swing.JLabel hab83;
    private javax.swing.JLabel hab9;
    private javax.swing.JLabel hab92;
    private javax.swing.JLabel hab93;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JComboBox<String> tip_H;
    // End of variables declaration//GEN-END:variables
}
